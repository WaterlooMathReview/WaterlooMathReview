%x=[0,1]
 
%Define constants
 %M = 2E30; R=7E7; c=3E8;G=6.67E-11;
 M = 1/pi; R=1;
%define the resolution
 Nx =128;
 dx = R/(Nx+1);
 x = (1:Nx+1)'*dx;
 x_ext = (1:(Nx+1)*2)'*dx;
 
 %Integrate rho
 rho = M/(4/3*pi*R^3)*ones(Nx+1,1);
 m   = zeros(Nx+1,1);
 for i=2:Nx+1
    m(i) = m(i-1) + abs(4*pi*((x(i) + x(i-1))/2)^2*(x(i)-x(i-1))*rho(i));
 end;
 figure(2); clf; plot(x,m);
 %m= G*m/(c);
 
 
 %Define A
 A = 1./(1-2*m./(x));
 p = 2/3*rho;
 
 %Solve for B
dB = 2*A./(x.^2).*(m + 4*pi*x.^3.*p);
lnB = zeros(Nx+1,1);
lnB(end) = log(1-2*m(end)/x(end)); 
for i=1:Nx
    lnB(end-i) = lnB(end-i+1) - dx*dB(end-i+1);
end;

B = exp(lnB);
%Extend the solution
M = m(end);
A_ext = zeros(2*(Nx+1),1); A_ext(1:Nx+1) = A(1:end);
A_ext(Nx+2:end) = 1./(1-2*M./x_ext(Nx+2:end));

B_ext = zeros(2*(Nx+1),1); B_ext(1:Nx+1) = B(1:end);
B_ext(Nx+2:end) = 1./A_ext(Nx+2:end); 

 %%%%%%%%%%%%%%%%%%%%%% print  
  fig1 = figure(1),clf, colormap(flipud(gray(10)));
  set(gcf,'DefaultLineLineWidth',2,'DefaultTextFontSize',14,...
    'DefaultTextFontWeight','bold','DefaultAxesFontSize',14,...
      'DefaultAxesFontWeight','bold', 'DefaultTextFontName','Arial',...
      'DefaultAxesFontName','Arial','Color','w');
  plot(x_ext,A_ext,'blue',x_ext,B_ext,'red'); grid on;
  %axis([0 x_ext(m) 0 10]);
  legend('A','B','Location','NorthWest');
  xlabel('Length');
  ylabel('Value');
    
  print(fig1,'-dpdf','Int_Metric'); 
  
          
