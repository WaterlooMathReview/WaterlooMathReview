clear all; close all;

% Spectral code for relativistic Convection
% set grid on [-2pi ,2pi]
 Nx = 512; 
 Lx = 2*pi;
 dt  = 1e-5; 
 nt  = 2e5;
 
 %Define computational grid
dxi = 2*pi/Nx; xi = dxi*(-Nx/2+1:Nx/2)';
x=Lx*xi/(2*pi);

%define Wavenumbers k,l on grid
 dk=2*pi/Lx;
ksvec=zeros(size(x));
ksvec(1)=0; ksvec(Nx/2+1)=0;
for ii=2:(Nx/2)
   ksvec(ii)=ii-1;
   ksvec(Nx/2+ii)=-Nx/2 + ii -1;
end
k=ksvec*dk; ik = sqrt(-1)*k;


%Run through all values of C

 for C = [0,1/3,2/3];
     
% initial condition: upward jump from 0 to 1 at x=0.2
 v0 = 0.5*ones(Nx,1);%sech(10*(x-0.5));
 e0 = sech(x/.5) + 1;
 v  = v0; e = e0;
 v_old = v0;  
 gamma_old =  sqrt(1 - v_old.^2).^(-1); 
% Assume Doubly Periodic Domain
% this will be ok until shock hits boundary

n = 0;
 while n < nt+1
 for j = 1:1e4;
 
  
  %Ganerate the Compresibility Number
  gamma = sqrt(1 - v.^2).^(-1); 

  %Define u = gamma*v
  u = gamma.*v;
 
  
  %Save the Data
  if n == 0 || n== nt/2 || n==nt; save(sprintf('Data_C%d_t=%d.mat',C*3,n),'x','n','dt','v','e');   end;
  
 %4rd Order Runge-Kutta Methodgamma
 % Step 1
 lnex = real(ifft(ik.*fft(log(e))));
 uex = real(ifft(ik.*fft(e.*u))); u2x = real(ifft(ik.*fft(u.^2/2)));
 q1a =  dt*(-C/(1+C)*lnex - u2x )./gamma; q1b = dt*( -uex)./gamma;
 
 %Step 2
 lnex = real(ifft(ik.*fft(log(e+ q1b/2))));
 uex = real(ifft(ik.*fft((e+q1b/2).*(u + q1a/2)))); u2x = real(ifft(ik.*fft((u + q1a/2).^2/2)));
 q2a =  dt*(-C/(1+C)*lnex - u2x )./gamma; q2b = dt*( -uex)./gamma;

 
 %Step 3
 lnex = real(ifft(ik.*fft(log(e+ q2b/2))));
 uex = real(ifft(ik.*fft((e+q2b/2).*(u + q2a/2)))); u2x = real(ifft(ik.*fft((u + q2a/2).^2/2)));
 q3a =  dt*(-C/(1+C)*lnex - u2x )./gamma; q3b = dt*( -uex)./gamma;
 
 %Step 4
 lnex = real(ifft(ik.*fft(log(e+ q3b))));
 uex = real(ifft(ik.*fft((e+q3b).*(u + q3a/2)))); u2x = real(ifft(ik.*fft((u + q3a).^2/2)));
 q4a =  dt*(-C/(1+C)*lnex - u2x )./gamma; q4b = dt*( -uex)./gamma;

 %Update 
 u = u +(q1a + 2*q2a + 2*q3a + q4a)/6; e = (e.*gamma +(q1b + 2*q2b + 2*q3b + q4b)/6)./gamma; 
 

  %Replace the Gamma - Approximation that Gamma is constant through one
  %iteration
  v = u./gamma;

  %Update n
  n = n+1; 
  
end;
 
 
  % Plot solutions from each method at each time step
   fig1 = figure(1);clf; colormap(jet); axis tight;
   set(gcf,'DefaultLineLineWidth',1.2,'DefaultTextFontSize',14,...
  'DefaultTextFontWeight','bold','DefaultAxesFontSize',14,...
  'DefaultAxesFontWeight','bold', 'DefaultTextFontName','Arial',...
  'DefaultAxesFontName','Arial','Color','w');
   set(gcf,'papersize',[11 8.5]);
   set(gcf,'paperposition',[0 0 11 8.5]);
   
    subplot(2,1,1);
    plot(x,e,'k'); axis([-pi pi 1 2.1]); grid on;
    ylabel('e','FontSize',16);
    subplot(2,1,2);hold on; grid on;
    %plot(x,u_par,'red'); 
    plot(x,v,'k'); axis([-pi pi 0 1]); 
    hold off;
    ylabel('v','FontSize',16);
    xlabel('Width','FontSize',16);
    title(sprintf('Time = %d',n*dt));
    pause(.1)
    drawnow;



 end;
 end;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Output Images


%Code Generates the Plots at various times.

clear all; 
close all; 

% Plot solutions from each method at each time step
   fig1 = figure(1);clf; colormap(jet); axis tight;
   set(gcf,'DefaultLineLineWidth',1.2,'DefaultTextFontSize',14,...
  'DefaultTextFontWeight','bold','DefaultAxesFontSize',14,...
  'DefaultAxesFontWeight','bold', 'DefaultTextFontName','Arial',...
  'DefaultAxesFontName','Arial','Color','w');
   set(gcf,'papersize',[18 6]);
   set(gcf,'paperposition',[0 0 18 6]);
   
   
   load Data_C0_t=0.mat
   subplot(2,3,1);
   plot(x,e,'k'); axis([-pi pi 1 2.1]); grid on;
   hold on; 
   load('Data_C1_t=0.mat','e'); plot(x,e,'b--'); 
   load('Data_C2_t=0.mat','e');plot(x,e,'r-.'); 
   hold off; 
   ylabel('e','FontSize',16);
   title(sprintf('Time = %d',n*dt));
   subplot(2,3,4);  grid on;
   plot(x,v,'k'); axis([-pi pi 0 1]); 
   hold on; 
   load('Data_C1_t=0.mat','v'); plot(x,v,'b--'); 
   load('Data_C2_t=0.mat','v');plot(x,v,'r-.'); 
   hold off;
    ylabel('v','FontSize',16);
    xlabel('Width','FontSize',16);

    
   clear; 
   load Data_C0_t=100000.mat;
   subplot(2,3,2);
   plot(x,e,'k'); axis([-pi pi 1 2.1]); grid on;
   ylabel('e','FontSize',16);
    hold on; 
   load('Data_C1_t=100000.mat','e'); plot(x,e,'b--'); 
   load('Data_C2_t=100000.mat','e');plot(x,e,'r-.'); 
   hold off; 
   title(sprintf('Time = %d',n*dt));
   subplot(2,3,5);  
   plot(x,v,'k'); axis([-pi pi 0 1]); 
   hold on; 
   load('Data_C1_t=100000.mat','v'); plot(x,v,'b--'); 
   load('Data_C2_t=100000.mat','v');plot(x,v,'r-.'); 
   hold off;grid on;
   ylabel('v','FontSize',16);
   xlabel('Width','FontSize',16);
    
    
    clear; 
    load Data_C0_t=200000.mat;
     subplot(2,3,3);
   plot(x,e,'k'); axis([-pi pi 1 2.1]); grid on;
   ylabel('e','FontSize',16);
   hold on; 
   load('Data_C1_t=200000.mat','e'); plot(x,e,'b--'); 
   load('Data_C2_t=200000.mat','e');plot(x,e,'r-.'); 
   hold off; 
   title(sprintf('Time = %d',n*dt));
   subplot(2,3,6); 
   plot(x,v,'k'); axis([-pi pi 0 1]); 
   hold on; 
   load('Data_C1_t=200000.mat','v'); plot(x,v,'b--'); 
   load('Data_C2_t=200000.mat','v');plot(x,v,'r-.'); 
   hold off;
   grid on;
    ylabel('v','FontSize',16);
    xlabel('Width','FontSize',16);
    
    
    fig1 = figure(1);
    print(fig1,'-depsc','RelFluidOut.eps');